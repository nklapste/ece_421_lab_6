#include "mylib.h"

void foo()
{
    cout << "Hello World!" << endl;
}

int add(int a, int b)
{
    return a+b;
}
