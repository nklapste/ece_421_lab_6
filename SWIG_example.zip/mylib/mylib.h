#include <iostream>

using namespace std;

void foo();
int  add(int a, int b);
