require 'mkmf'
create_makefile('mylib')
