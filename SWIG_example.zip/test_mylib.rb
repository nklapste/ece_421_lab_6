require_relative 'mylib/mylib'

# void method call
Mylib::foo

# method that takes arguments and returns integer
sum = Mylib::add(30, 12)
print sum
